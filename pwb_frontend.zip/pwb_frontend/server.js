var express = require("express");
var connection = require('./database');
var bodyParser = require('body-parser');
var app = express();
var path = require('path');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use('/assets/css/portal.css', express.static(path.join(__dirname, 'assets/css/portal.css')));  //static files
app.use('/assets/images/background', express.static(path.join(__dirname, 'assets/images/background')));  //static files
app.use('/assets/images/profiles', express.static(path.join(__dirname, 'assets/images/profiles')));  //static files
app.use('/assets/images/users', express.static(path.join(__dirname, 'assets/images/users')));  //static files
app.use('/assets/plugins/fontawesome/js/all.min.js', express.static(path.join(__dirname, 'assets/plugins/fontawesome/js/all.min.js')));  //static files
app.use('/assets/images', express.static(path.join(__dirname, 'assets/images')));  //static files
app.use('/assets/plugins', express.static(path.join(__dirname, 'assets/plugins')));  //static files
app.use('/assets/plugins/bootstrap/css', express.static(path.join(__dirname, 'assets/plugins/bootstrap/css')));  //static files
app.use('/assets/plugins/bootstrap/js', express.static(path.join(__dirname, 'assets/plugins/bootstrap/js')));  //static files
app.use('/assets/plugins/chart.js', express.static(path.join(__dirname, 'assets/plugins/chart.js')));  //static files
app.use('/assets/plugins/fontawesome', express.static(path.join(__dirname, 'assets/plugins/fontawesome')));  //static files
app.use('/assets/plugins/fontawesome/css', express.static(path.join(__dirname, 'assets/plugins/fontawesome/css')));  //static files
app.use('/assets/plugins/fontawesome/js', express.static(path.join(__dirname, 'assets/plugins/fontawesome/js')));  //static files
app.use('/assets/plugins/fontawesome/less', express.static(path.join(__dirname, 'assets/plugins/fontawesome/less')));  //static files
app.use('/assets/plugins/fontawesome/metadata', express.static(path.join(__dirname, 'assets/plugins/fontawesome/metadata')));  //static files
app.use('/assets/plugins/fontawesome/scss', express.static(path.join(__dirname, 'assets/plugins/fontawesome/scss')));  //static files
app.use('/assets/plugins/fontawesome/sprites', express.static(path.join(__dirname, 'assets/plugins/fontawesome/sprites')));  //static files
app.use('/assets/plugins/fontawesome/svgs', express.static(path.join(__dirname, 'assets/plugins/fontawesome/svgs')));  //static files
app.use('/assets/plugins/fontawesome/webfonts', express.static(path.join(__dirname, 'assets/plugins/fontawesome/webfonts')));  //static files
app.use('/assets/scss/app', express.static(path.join(__dirname, 'assets/scss/app')));  //static files
app.use('/assets/scss/bootstrap', express.static(path.join(__dirname, 'assets/scss/bootstrap')));  //static files
app.use('/assets/scss', express.static(path.join(__dirname, 'assets/scss')));  //static files

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

app.get('/create-team', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'select.html'));
});

app.post('/select', (req, res) => {
  const selectedBtn = req.body.btn;
  if (selectedBtn === 'user') {
    res.redirect('/login');
  } else {
    res.redirect('/admin');
  }
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/login', (req, res) => {
  const { userID, FirstName, LastName, email, password, role } = req.body;

  const query = 'INSERT INTO userss (UserID, FirstName, LastName, Email, Password) VALUES (?, ?, ?, ?, ?)';
  const values = [userID, FirstName, LastName, email, password];

  connection.query(query, values, (err, result) => { 
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json({ message: 'User created successfully' });
    }

    if (role === 'User') {
      res.redirect('/board');
    } else if (role === 'Leader') {
      res.redirect('/team');
    }
  });
});

// Remove this route since it's handled by the static file serving middleware
// app.get('/team', (req, res) => {
//   res.sendFile(path.join(__dirname, 'public', 'Team.html'));
// });

app.post('/team', (req, res) => {
  const { name, member1, member2, member3, member4, member5, member6, teamdescription } = req.body;

  const query = 'INSERT INTO Groupss (GrouptName, Members, GroupDescrip) VALUES (?, ?, ?)';
  const values = [name, `${member1},${member2},${member3},${member4},${member5},${member6}`, teamdescription];

  connection.query(query, values, (err, result) => { 
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json({ message: 'Data inserted successfully' });
    }
  });
});

app.get('/project', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});

app.post('/project', (req, res) => {
  const { ProjectID, AdminID, UserID, MapID, GroupID, ProjectName, start_date, end_date } = req.body;

  const query = 'INSERT INTO Project (ProjectID, AdminID, UserID, MapID, GroupID, ProjectName, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  const values = [ProjectID, AdminID, UserID, MapID, GroupID, ProjectName, start_date, end_date];

  connection.query(query, values, (err, result) => { 
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json({ message: 'Data inserted successfully' });
      res.redirect('/board');
    }
  });
});

app.get('/board', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'board.html'));
});

app.get('/issue', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'issue.html'));
});

app.post('/issue', (req, res) => {
  const {CustomerID,Descrip,Tyype,Files,Comments,Daate,CurrentState,LevelOfPrior} = req.body;

  const query = `INSERT INTO Issue (CustomerID,Descrip, Tyype, Files, Comments, Daate,CurrentState, LevelOfPrior) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
  const values = [CustomerID,Descrip,Tyype,Files,Comments,Daate,CurrentState,LevelOfPrior];

  connection.query(query, values, (err, result) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json({ message: 'Data inserted successfully' });
      res.redirect('/board');
    }
  });
});

app.get('/docs', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'docs.html'));
});

app.get('/notifications', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'notifications.html'));
});

app.get('/chart', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'charts.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.post('/admin', (req, res) => {
  const {AdminID,  FirstName, LastName, password, AccessLevel,  role } = req.body;

  const query = 'INSERT INTO Adminn (AdminID,  FirstName, LastName, password, AccessLevel) VALUES (?, ?, ?, ?, ?)';
  const values = [AdminID,  FirstName, LastName, password, AccessLevel];

  connection.query(query, values, (err, result) => { 
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json({ message: 'Data inserted successfully' });
      res.redirect('/board');
    }
    if (role === 'Add Project') {
      res.redirect('/project');
    } else if (role === 'Delete Project') {
      res.redirect('/delete');
    }
  });

  app.get('/delete', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'delete.html'));
  });
});







app.listen(3000, function() {
  console.log('App listening on port 3000');
  // The following connection code is unnecessary in this context
});
